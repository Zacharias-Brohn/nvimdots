dofile(vim.g.base46_cache .. "git")

return {
    signs = {
        delete = { text = "󰍵" },
        changedelete = { text = "󱕖" },
    },
    attach_to_untracked = true,
}
